import Mock from 'mockjs'
Mock.mock(/getNewsList/, {
    'list': [{
            url: 'ddd',
            title: 'title1'
        },
        {
            url: 'ddd',
            title: 'title2'
        }
    ]
})
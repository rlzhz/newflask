<template>
    <h1>Hellocomponent {{ msg }}</h1>
</template>

<script>
export default {
    name:"HellComponent",
    data(){
        return{
            msg:"欢迎zhaohuizhe"
        }
    },
}
</script>

<style>

h1{
    color: red;

}
</style>

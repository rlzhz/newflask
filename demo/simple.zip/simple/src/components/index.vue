<template>
    <div>
        index.vue
    </div>
</template>

<script>
export default {
    
}
</script>
<style>

</style>